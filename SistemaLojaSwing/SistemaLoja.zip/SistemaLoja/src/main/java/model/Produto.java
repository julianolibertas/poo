package model;

public class Produto {
    private int codProd;
    private String descricao;
    private double preco;
    private int codMarca;

    // Construtores
    public Produto() {}

    public Produto(String descricao, double preco, int codMarca) {
        this.descricao = descricao;
        this.preco = preco;
        this.codMarca = codMarca;
    }

    // Getters e Setters
    public int getCodProd() { return codProd; }
    public void setCodProd(int codProd) { this.codProd = codProd; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public double getPreco() { return preco; }
    public void setPreco(double preco) { this.preco = preco; }
    public int getCodMarca() { return codMarca; }
    public void setCodMarca(int codMarca) { this.codMarca = codMarca; }
}
