package view;

public class TesteDriver {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver encontrado com sucesso! O tradutor está pronto.");
        } catch (ClassNotFoundException e) {
            System.out.println("Erro: O Driver não foi encontrado. Revise os passos de instalação.");
        }
    }
}
