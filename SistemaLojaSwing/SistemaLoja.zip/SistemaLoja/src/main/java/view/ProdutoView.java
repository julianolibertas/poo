package view;


import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import dao.ProdutoDAO;
import model.Produto;

public class ProdutoView extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtCodProd, txtDescricao, txtPreco, txtCodMarca;
    private JButton btnSalvar, btnAtualizar, btnExcluir, btnLimpar;
    private JTable tabelaProdutos;
    private DefaultTableModel tableModel;
    private ProdutoDAO dao;

    public ProdutoView() {
        dao = new ProdutoDAO();
        setTitle("Cadastro de Produtos - Loja Exemplo");
        setSize(600, 619);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());

        inicializarComponentes();
        carregarDadosTabela();
    }

    private void inicializarComponentes() {
        // Painel Superior (Formulário)
        JPanel painelForm = new JPanel(new GridLayout(4, 2, 5, 5));
        painelForm.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        painelForm.add(new JLabel("ID (Vazio para criar):"));
        txtCodProd = new JTextField();
        txtCodProd.setEditable(false);
        painelForm.add(txtCodProd);

        painelForm.add(new JLabel("Descrição:"));
        txtDescricao = new JTextField();
        painelForm.add(txtDescricao);

        painelForm.add(new JLabel("Preço:"));
        txtPreco = new JTextField();
        painelForm.add(txtPreco);

        painelForm.add(new JLabel("ID da Marca:"));
        txtCodMarca = new JTextField();
        painelForm.add(txtCodMarca);

        getContentPane().add(painelForm, BorderLayout.NORTH);

        // Painel Central (Botões)
        JPanel painelBotoes = new JPanel(new FlowLayout());
        btnSalvar = new JButton("Salvar");
        btnAtualizar = new JButton("Atualizar");
        btnExcluir = new JButton("Excluir");
        btnLimpar = new JButton("Limpar Campos");

        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnAtualizar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnLimpar);

        getContentPane().add(painelBotoes, BorderLayout.CENTER);

        // Painel Inferior (Tabela)
        tableModel = new DefaultTableModel(new String[]{"ID", "Descrição", "Preço", "Marca ID"}, 0);
        tabelaProdutos = new JTable(tableModel);
        getContentPane().add(new JScrollPane(tabelaProdutos), BorderLayout.SOUTH);

        // Eventos dos Botões
        btnSalvar.addActionListener(this::salvarProduto);
        btnAtualizar.addActionListener(this::atualizarProduto);
        btnExcluir.addActionListener(this::excluirProduto);
        btnLimpar.addActionListener(e -> limparCampos());

        // Evento de clique na tabela para preencher o formulário
        tabelaProdutos.getSelectionModel().addListSelectionListener(e -> {
            if (tabelaProdutos.getSelectedRow() != -1) {
                int linha = tabelaProdutos.getSelectedRow();
                txtCodProd.setText(tableModel.getValueAt(linha, 0).toString());
                txtDescricao.setText(tableModel.getValueAt(linha, 1).toString());
                txtPreco.setText(tableModel.getValueAt(linha, 2).toString());
                txtCodMarca.setText(tableModel.getValueAt(linha, 3).toString());
            }
        });
    }

    private void salvarProduto(ActionEvent e) {
        try {
            Produto p = new Produto();
            p.setDescricao(txtDescricao.getText());
            p.setPreco(Double.parseDouble(txtPreco.getText()));
            p.setCodMarca(Integer.parseInt(txtCodMarca.getText()));

            dao.criar(p);
            JOptionPane.showMessageDialog(this, "Produto salvo!");
            limparCampos();
            carregarDadosTabela();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
        }
    }

    private void atualizarProduto(ActionEvent e) {
        try {
            if (txtCodProd.getText().isEmpty()) throw new Exception("Selecione um produto.");
            Produto p = new Produto();
            p.setCodProd(Integer.parseInt(txtCodProd.getText()));
            p.setDescricao(txtDescricao.getText());
            p.setPreco(Double.parseDouble(txtPreco.getText()));
            p.setCodMarca(Integer.parseInt(txtCodMarca.getText()));

            dao.atualizar(p);
            JOptionPane.showMessageDialog(this, "Produto atualizado!");
            limparCampos();
            carregarDadosTabela();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
        }
    }

    private void excluirProduto(ActionEvent e) {
        try {
            if (txtCodProd.getText().isEmpty()) throw new Exception("Selecione um produto.");
            int id = Integer.parseInt(txtCodProd.getText());
            dao.deletar(id);
            JOptionPane.showMessageDialog(this, "Produto excluído!");
            limparCampos();
            carregarDadosTabela();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
        }
    }

    private void limparCampos() {
        txtCodProd.setText("");
        txtDescricao.setText("");
        txtPreco.setText("");
        txtCodMarca.setText("");
        tabelaProdutos.clearSelection();
    }

    private void carregarDadosTabela() {
        tableModel.setRowCount(0); // Limpa a tabela
        List<Produto> lista = dao.listar();
        for (Produto p : lista) {
            tableModel.addRow(new Object[]{p.getCodProd(), p.getDescricao(), p.getPreco(), p.getCodMarca()});
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ProdutoView().setVisible(true);
        });
    }
}
