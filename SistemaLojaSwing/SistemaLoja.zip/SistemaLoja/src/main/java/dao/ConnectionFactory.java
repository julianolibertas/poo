package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	private static final String URL = "jdbc:mysql://127.0.0.1:3306/loja_exemplo";
    private static final String USER = "root";
    private static final String PASS = "senha_aqui";
    
    public static Connection getConnection() {
    	try {
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (SQLException e) {
            throw new RuntimeException("Erro na conexão com o banco de dados: " + e.getMessage());
        }
    	
    }
    
}
